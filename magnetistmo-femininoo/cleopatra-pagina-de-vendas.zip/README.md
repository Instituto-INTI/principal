# Cleópatra — Protocolo do Magnetismo Feminino

Página responsiva em HTML, CSS e JavaScript, sem dependências de execução ou etapa de build.

## Visualizar

Execute `npm run dev` nesta pasta e abra http://127.0.0.1:4173.

## Ativar a comercialização

Edite `dist/config.js`:

- `videoUrl`: URL HTTPS de vídeo MP4/WebM, YouTube ou Vimeo.
- `checkoutUrl`: URL HTTPS real da plataforma de pagamento.
- `offerEndsAt`: data real em formato ISO com fuso (por exemplo, `2026-12-15T23:59:59-03:00`). Sem data, o contador permanece oculto. Ele não reinicia por visitante e, quando expira, encerra a oferta na página.

Enquanto os links estiverem vazios, a página comunica que o vídeo e as inscrições estarão disponíveis em breve. Não há captura de dados nem simulação de pagamento. A entrega do produto e o reembolso devem ser configurados na plataforma de pagamento.

O preço do PDF foi preservado: 12 parcelas de R$ 10,03 (total R$ 120,36) ou R$ 97,00 à vista. O acesso é de 1 ano, com 7 dias de garantia. Antes de abrir vendas, confirme esses termos no checkout.

## Material e conteúdo

As imagens, os três relatos e a fotografia de João Rafael foram extraídos do PDF fornecido. O arquivo de menor resolução entre os relatos foi preservado como no original; uma versão em alta resolução melhora a leitura. As conversas são exibidas com o cabeçalho recortado pelo layout para reduzir exposição de identificação. A cópia mantém a sequência do framework, com redação editorial e sem garantir controle sobre sentimentos ou atitudes de terceiros. O contador depende de um prazo real, ainda não fornecido.

Inclui navegação por âncoras, apresentação em modal, integração configurável de vídeo e checkout, carrossel com navegação, pausa, teclado e gesto de deslizar, perguntas expansíveis e resumo fixo da oferta. As animações respeitam a preferência por movimento reduzido. Fontes do Google Fonts, com alternativas locais em caso de indisponibilidade.

## Publicação

Os arquivos de `dist/` podem ser hospedados em qualquer serviço estático. A identidade do Sites está em `.openai/hosting.json`. Não é necessário instalar pacotes para executar a página.
